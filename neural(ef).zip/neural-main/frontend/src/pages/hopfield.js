export function addHopfieldCluster({ graph, cx, cy, count, radius, nodeSize, nextId, connectionProb }) {
  const ids = [];
  const angleStep = (2 * Math.PI) / count;

  for (let i = 0; i < count; i++) {
    const id = nextId();
    const x = cx + radius * Math.cos(i * angleStep);
    const y = cy + radius * Math.sin(i * angleStep);
    graph.addNode(id, {
      x,
      y,
      size: nodeSize,
      color: "#48dbfb",
      label: `Node ${id.split("-")[1]}`,
    });
    ids.push(id);
  }

  for (let i = 0; i < ids.length; i++) {
    for (let j = i + 1; j < ids.length; j++) {
      if (Math.random() * 100 < connectionProb) {
        graph.addEdge(ids[i], ids[j], { color: "white" });
      }
    }
  }

  return { ids };
}